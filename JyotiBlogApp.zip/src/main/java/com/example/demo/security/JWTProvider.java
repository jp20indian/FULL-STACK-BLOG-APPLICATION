package com.example.demo.security;

//import com.example.demo.entity.User;
import org.springframework.security.core.userdetails.User;
import com.example.demo.payload.LoginRequestDto;
import io.jsonwebtoken.Jwts;
//import org.apache.tomcat.util.net.openssl.ciphers.Authentication;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.security.Key;

@Service
public class JWTProvider {
    private Key key;

    @PostConstruct
    public void init()
    {
        key=Keys.secretKeyFor(SignatureAlgorithm.HS512);
    }
    public String generateToken(Authentication authentication)
    {
        System.out.println("--- "+authentication.getPrincipal());
        User principal = (User) authentication.getPrincipal();
        return Jwts.builder()
                .setSubject(principal.getUsername())
                .signWith(Keys.secretKeyFor(SignatureAlgorithm.HS512))
                .compact();
    }
}
