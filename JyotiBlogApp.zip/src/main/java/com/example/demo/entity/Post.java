package com.example.demo.entity;
import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor

@Entity
@Table(
        name = "posts"
)
public class Post {

    @Id
//    @Column(name="id")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;

    @Column(name = "title")
    private String title;

    @Column(name = "content",length = 100024)
    private String content;

    @Column(name="username")
    private String username;

    @Column(name = "time")
    private String time;

    @Column(name="date")
    private String date;

    @Column(name="imgurl")
    private String imgurl;

    @Column(name="category")
    private String  category;

    @Column(name="status")
    private String  status;

    @Column(name = "likes")
    private String likes;


    @OneToMany(mappedBy = "post", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<Comment> comments = new HashSet<>();

//    @ManyToOne(fetch = FetchType.LAZY)
//    @JoinColumn(name = "user_id")
//    private User user;
}
