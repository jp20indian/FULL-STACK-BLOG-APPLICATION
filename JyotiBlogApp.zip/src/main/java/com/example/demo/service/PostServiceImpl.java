package com.example.demo.service;

import com.example.demo.entity.Post;
import com.example.demo.payload.PostDto;
import com.example.demo.repository.PostRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PostServiceImpl {

    private PostRepository postRepository;

    public PostServiceImpl(PostRepository postRepository) {
        this.postRepository = postRepository;
    }
    public PostDto createPost(PostDto postDto) {

        System.out.println(postDto.getUsername()+"\n");

        // convert DTO to entity
        Post post = mapToEntity(postDto);

        Post newPost = postRepository.save(post);

        System.out.println(newPost.getUsername()+"\n");

        // convert entity to DTO
        PostDto postResponse = mapToDTO(newPost);
        System.out.println(postResponse.getUsername()+"\n");
        return postResponse;
    }

    public List<PostDto> getAllPosts() {
        List<Post> posts = postRepository.findAll();
        return posts.stream().map(post -> mapToDTO(post)).collect(Collectors.toList());
    }

    public PostDto getPostById(long id) {
        Post post = postRepository.findById(id).orElseThrow();
        return mapToDTO(post);
    }

    public PostDto updatePost(PostDto postDto, long id) {
        // get post by id from the database
        Post post = postRepository.findById(id).orElseThrow();

        post.setTitle(postDto.getTitle());
        post.setContent(postDto.getContent());
        post.setStatus(postDto.getStatus());
        post.setImgurl(postDto.getImgurl());
        post.setCategory(postDto.getCategory());
        post.setDate(postDto.getDate());
        post.setTime(postDto.getTime());

        Post updatedPost = postRepository.save(post);
        return mapToDTO(updatedPost);
    }

    public PostDto updatePostLike(PostDto postDto, long id) {
        // get post by id from the database
        Post post = postRepository.findById(id).orElseThrow();

        post.setTitle(postDto.getTitle());
        post.setContent(postDto.getContent());
        post.setStatus(postDto.getStatus());
        post.setImgurl(postDto.getImgurl());
        post.setCategory(postDto.getCategory());
        post.setDate(postDto.getDate());
        post.setTime(postDto.getTime());
        post.setLikes(postDto.getLikes());

        Post updatedPost = postRepository.save(post);
        return mapToDTO(updatedPost);
    }

//    @Override
    public void deletePostById(long id) {
        // get post by id from the database
        Post post = postRepository.findById(id).orElseThrow();
        postRepository.delete(post);
    }

    // convert Entity into DTO
    private PostDto mapToDTO(Post post){
        PostDto postDto = new PostDto();
        postDto.setId(post.getId());
        postDto.setTitle(post.getTitle());
        postDto.setContent(post.getContent());
        postDto.setUsername(post.getUsername());
        postDto.setDate(post.getDate());
        postDto.setTime(post.getTime());
        postDto.setCategory(post.getCategory());
        postDto.setImgurl(post.getImgurl());
        postDto.setStatus(post.getStatus());
        postDto.setLikes(post.getLikes());
        return postDto;
    }

    // convert DTO to entity
    private Post mapToEntity(PostDto postDto){
        Post post = new Post();
        post.setTitle(postDto.getTitle());
        post.setContent(postDto.getContent());
        post.setUsername(postDto.getUsername());
        post.setDate(postDto.getDate());
        post.setTime(postDto.getTime());
        post.setCategory(postDto.getCategory());
        post.setCategory(postDto.getCategory());
        post.setImgurl(postDto.getImgurl());
        post.setStatus(postDto.getStatus());
        post.setLikes(postDto.getLikes());
        return post;
    }


}
