package com.example.demo.service;

import com.example.demo.entity.User;
import com.example.demo.payload.LoginRequestDto;
import com.example.demo.payload.RegisterRequestDto;
import com.example.demo.repository.UserRepository;
import com.example.demo.security.JWTProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.security.Security;
import java.util.List;

@Service
public class AuthService {

    @Autowired
     private UserRepository userRepository;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JWTProvider jwtProvider;
    public void signup(RegisterRequestDto registerRequestDto)
    {
        User user=new User();
        user.setUsername(registerRequestDto.getUsername());
        user.setEmail(registerRequestDto.getEmail());
        user.setPassword( encodePassword(registerRequestDto.getPassword()));

//        System.out.println("\n Service"+user.getId()+user.getEmail()+user.getPassword()+user.getUsername());

        userRepository.save(user);
    }

    public String login(LoginRequestDto loginRequestDto)
    {
       Authentication authenticate = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(loginRequestDto.getUsername(),loginRequestDto.getPassword()));
        SecurityContextHolder.getContext().setAuthentication(authenticate);

        return jwtProvider.generateToken(authenticate);
    }

    private String encodePassword(String password)
    {
       return passwordEncoder.encode(password);
    }

    public List<User> getall() {
     return userRepository.findAll();
    }
}
