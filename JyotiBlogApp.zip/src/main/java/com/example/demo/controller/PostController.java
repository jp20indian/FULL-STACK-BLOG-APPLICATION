package com.example.demo.controller;

import com.example.demo.payload.CommentDto;
import com.example.demo.service.CommentServiceImpl;
import org.springframework.http.HttpRequest;
import org.springframework.web.bind.annotation.CrossOrigin;
import com.example.demo.payload.PostDto;
import com.example.demo.service.PostServiceImpl;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@CrossOrigin(origins="*", maxAge = 3600,
        allowedHeaders={"x-auth-token", "x-requested-with", "x-xsrf-token"})
@RestController
//@CrossOrigin(origins = "*")
@RequestMapping("/api/posts")
public class PostController {

    private PostServiceImpl postService;
    private CommentServiceImpl commentService;

    public PostController(PostServiceImpl postService,CommentServiceImpl commentService) {
        this.postService = postService;
        this.commentService = commentService;
    }

    // create blog post rest api
    @PostMapping
    public ResponseEntity<PostDto> createPost(@RequestBody PostDto postDto){
        System.out.println(postDto.getUsername()+"\n");
        return new ResponseEntity<>(postService.createPost(postDto), HttpStatus.CREATED);
    }

    @PostMapping("/{postId}")
    public ResponseEntity<PostDto> updatePost(@PathVariable(name = "postId") long postId, @RequestBody PostDto postDto)
    {
        System.out.print(postId+"\n"+postDto.getUsername()+"\n"+postDto.getContent()+"\n"+postDto.getTime()+"\n"+postDto.getDate()+"\n"+postDto.getTitle()+"\n"+postDto.getImgurl()+"\n"+postDto.getCategory()+"\n"+postDto.getStatus());

        PostDto postResponse = postService.updatePost(postDto, postId);

        return new ResponseEntity<>(postResponse,HttpStatus.OK);
    }


    @PostMapping("/{postId}/updatelike")
    public ResponseEntity<PostDto> updatePostLikes(@PathVariable(name = "postId") long postId, @RequestBody PostDto postDto)
    {
        System.out.print(postId+"\n"+postDto.getUsername()+"\n"+postDto.getContent()+"\n"+postDto.getTime()+"\n"+postDto.getDate()+"\n"+postDto.getTitle()+"\n"+postDto.getImgurl()+"\n"+postDto.getCategory()+"\n"+postDto.getStatus()+"\n"+postDto.getLikes());

        PostDto postResponse = postService.updatePostLike(postDto, postId);

        return new ResponseEntity<>(postResponse,HttpStatus.OK);
    }

    // get all posts rest api
    @GetMapping
    public ResponseEntity<List<PostDto>> getAllPosts()
    {

        System.out.println("Get post executed");
        return new ResponseEntity<>(postService.getAllPosts(), HttpStatus.OK);
    }

    @GetMapping("/{postid}/comments")
    public ResponseEntity<List<CommentDto>> getCommentsByPostId(@PathVariable(name = "postid") long postid ){

        System.out.println("get all comments ");

        return new ResponseEntity<>(commentService.getCommentsByPostId(postid),HttpStatus.OK);
//        return commentService.getCommentsByPostId(postId);
    }

    @PostMapping("/{postId}/comments")
    public ResponseEntity<CommentDto> createComment(@PathVariable(value = "postId") long postId,
                                                    @RequestBody CommentDto commentDto){

        System.out.println("Comment Posted");

        return new ResponseEntity<>(commentService.createComment(postId, commentDto), HttpStatus.CREATED);
    }

    @GetMapping("/{postId}/comments/{commentId}")
    public ResponseEntity<CommentDto> updateCommentLikeById(@PathVariable(value = "commentId") long commentId)
    {
//        System.out.println("In controller: "+commentService.updateLike(commentId).getLikes());
        return new ResponseEntity<>( commentService.updateLike(commentId), HttpStatus.CREATED);
    }

    // get post by id
    @GetMapping("/{id}")
    public ResponseEntity<PostDto> getPostById(@PathVariable(name = "id") long id){

        return ResponseEntity.ok(postService.getPostById(id));
    }

    @GetMapping("/{id}/delete")
    public ResponseEntity<String> deletePost(@PathVariable(name = "id") long id){

        postService.deletePostById(id);

        return new ResponseEntity<>("Post entity deleted successfully.", HttpStatus.OK);
    }
}

