package com.example.demo.controller;

import com.example.demo.payload.LoginRequestDto;
import com.example.demo.payload.RegisterRequestDto;
import com.example.demo.service.AuthService;
import org.apache.tomcat.util.json.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/signup")
    public ResponseEntity signup(@RequestBody RegisterRequestDto registerRequest) {
//        System.out.println("\n CONTROLLER"+registerRequest.getId()+registerRequest.getEmail()+registerRequest.getPassword()+registerRequest.getUsername());
        authService.signup(registerRequest);
        return new ResponseEntity(HttpStatus.OK);
    }


    @PostMapping("/login")
    public ResponseEntity login(@RequestBody LoginRequestDto loginRequestDto) {
        System.out.println("Login sending : "+authService.login(loginRequestDto));
//        return authService.login(loginRequest);
        return new ResponseEntity(authService.login(loginRequestDto),HttpStatus.OK);
    }

    @GetMapping("/signup")
    public ResponseEntity getall() {
//        System.out.println("\n CONTROLLER"+registerRequest.getId()+registerRequest.getEmail()+registerRequest.getPassword()+registerRequest.getUsername());
//        authService.signup(registerRequest);
        return new ResponseEntity(authService.getall(),HttpStatus.OK);
    }


}
