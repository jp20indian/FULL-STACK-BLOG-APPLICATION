package com.example.demo.payload;

import lombok.Data;

import javax.persistence.Column;

@Data
public class PostDto {
    private long id;
    private String title;
    private String content;
    private String username;
    private String time;
    private String date;
    private String imgurl;
    private String  category;
    private String  status;
    private String likes;
}