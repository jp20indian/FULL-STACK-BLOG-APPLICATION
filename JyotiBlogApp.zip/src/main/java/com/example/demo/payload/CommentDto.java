package com.example.demo.payload;

import lombok.Data;

@Data
public class CommentDto {
    private long id;

    private String username;
    private String body;
    private String likes;

}
