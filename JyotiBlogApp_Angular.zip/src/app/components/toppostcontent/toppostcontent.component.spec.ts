import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ToppostcontentComponent } from './toppostcontent.component';

describe('ToppostcontentComponent', () => {
  let component: ToppostcontentComponent;
  let fixture: ComponentFixture<ToppostcontentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ToppostcontentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ToppostcontentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
