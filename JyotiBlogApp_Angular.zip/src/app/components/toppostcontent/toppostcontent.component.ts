import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-toppostcontent',
  templateUrl: './toppostcontent.component.html',
  styleUrls: ['./toppostcontent.component.css']
})
export class ToppostcontentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
