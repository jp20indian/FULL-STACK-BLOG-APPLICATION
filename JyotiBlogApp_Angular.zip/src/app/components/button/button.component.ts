import { Component, Input, OnInit } from '@angular/core';
import { ThemechangeService } from 'src/app/services/themechange.service';

@Component({
  selector: 'app-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.css']
})
export class ButtonComponent implements OnInit {

  @Input() item:any;

  sunclicked:any=0;
  moonclicked:any=1;

  flag:any=0;

  constructor(private themechangeservice:ThemechangeService) { }

  ngOnInit(): void {
  }

  themeclick(value:any)
  {
    if(value===1)
    {
      this.sunclicked=value;
      this.themechangeservice.sunclicked(1);
      console.log("sun click");
      this.moonclicked=0;
    }
    else
    {
      this.sunclicked=value;
      this.themechangeservice.moonclicked(1);
      console.log("moon click");
      this.moonclicked=1;
    }

  }

  increaselike()
  {
    if(!this.flag){
    console.log(this.item);
    this.item=this.item+1;
    this.flag=1;
    }
    else{
      this.item=this.item-1;
      this.flag=0;
    }
  }

  // api request to update likes for post id

}
