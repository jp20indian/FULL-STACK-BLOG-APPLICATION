import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-signupbuttons',
  templateUrl: './signupbuttons.component.html',
  styleUrls: ['./signupbuttons.component.css']
})
export class SignupbuttonsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
