import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SignupbuttonsComponent } from './signupbuttons.component';

describe('SignupbuttonsComponent', () => {
  let component: SignupbuttonsComponent;
  let fixture: ComponentFixture<SignupbuttonsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SignupbuttonsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SignupbuttonsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
