import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css'],
  encapsulation: ViewEncapsulation.ShadowDom
})
export class SignupComponent implements OnInit {
  signupForm!: FormGroup;
  email: any = '';
  username: any = '';
  password: any = '';
  confirmpassword: any = '';

  signuptitle = "Sign Up";

  flag = 0;
  flag1 = 0;

  usernameerror: any = 0;
  emailerror: any = 0;


  @Output() newItemEvent = new EventEmitter<any>();
  @Output() newItemEvent1 = new EventEmitter<any>();

  constructor(private fb: FormBuilder, private http: HttpClient) { }

  ngOnInit(): void {

    this.signupForm = this.fb.group({
      email: this.fb.control('', [Validators.required]),
      username: this.fb.control('', [Validators.required]),
      password: this.fb.control('', [Validators.required]),
      confirmpassword: this.fb.control('', [Validators.required])
    });
  }

  Email(e: any) {
    this.email = e.target.value;

    this.http.get("http://localhost:4501/api/auth/signup").subscribe((res: any) => {

      for (let i = 0; i < res.length; i++) {

        if (res[i].email === this.email||this.email.includes("@")===false) {

          if(res[i].email === this.email)
          {
            this.signuptitle="Email Already Exists!";
          }
          else if(this.email.includes("@")===false)
          {
            this.signuptitle="Incorrect Format! Include @";
          }
          this.flag = 1;
          console.log("Email NAME TAKEN !" + this.flag)
          break;
        }
        else {
          this.flag = 0;
          this.signuptitle="Great Going!";
        }
      }

      this.addalertemail(this.flag, e, this.email);

    })
  }

  addalertemail(flag: any, e: any, email: any) {
    console.log(e.path[0], flag, email);
    if (email === "") {
      e.path[0].style.border = "1px solid #DADCE0";
    }
    else {
      if (flag === 1) {
        console.log("email not allowed");
        e.path[0].style.border = "1px solid red"; this.emailerror = 1;
      }
      else {
        e.path[0].style.border = "1px solid green";
        this.emailerror = 0;
      }
    }

  }

  Username(e: any) {
    this.username = e.target.value;

    this.http.get("http://localhost:4501/api/auth/signup").subscribe((res: any) => {

      console.log(res);
      for (let i = 0; i < res.length; i++) {
        console.log(res[i]);
        if (res[i].username === this.username) {
          this.signuptitle="Username Already Exists!"
          this.flag1 = 1;
          break;
        }
        else {
          this.signuptitle="Perfect Username!"
          this.flag1 = 0;
        }
      }

      this.addalertusername(this.flag1, e, this.username);

    })
  }

  addalertusername(flag: any, e: any, username: any) {
    console.log(e.path[0], flag, username);
    if (username === "") {
      e.path[0].style.border = "1px solid #DADCE0";
    }
    else {
      if (flag === 1) {
        e.path[0].style.border = "1px solid red"; this.usernameerror = 1;
      }
      else {
        e.path[0].style.border = "1px solid green";
      }
    }

  }

  BackSignup(e: any) {
    this.newItemEvent.emit(e);
  }

  SignUp() {

    if (this.usernameerror !== 0 || this.emailerror !== 0) {
    
      console.log(this.usernameerror + this.emailerror);
      this.signuptitle = "Invalid Username Or Password !"
      this.usernameerror = 0; this.emailerror = 0;
      this.newItemEvent1.emit(1);
    }
    else if (this.usernameerror === 0 && this.emailerror === 0) {

      if(this.signupForm.value.username!==""&&this.signupForm.value.email!==""&&this.signupForm.value.password!=="")
      {
      console.log(this.signupForm.value,this.usernameerror,this.emailerror);
      this.http.post<any>("http://localhost:4501/api/auth/signup", this.signupForm.value).subscribe(res => {

        this.signuptitle = "Successfully Signed Up ! Now Login."

        this.newItemEvent1.emit(0);

      })
    }

    }

  }


}
