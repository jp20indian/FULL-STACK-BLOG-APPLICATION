export class signuppayload{
    username:String='';
    email:String='';
    password:String='';
    confirmpassword:String='';
}