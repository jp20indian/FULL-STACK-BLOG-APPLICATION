import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import {FormControl, FormGroup} from '@angular/forms';
import {Router} from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { postpayload } from './postpayload';
import {LocalStorageService, SessionStorageService} from 'ngx-webstorage';
// import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-createpost',
  templateUrl: './createpost.component.html',
  styleUrls: ['./createpost.component.css'],
})
export class CreatepostComponent implements OnInit {

  addPostForm: FormGroup;
  title = new FormControl('');
  body = new FormControl('');
  imageurl=new FormControl('');
  time=new FormControl('');
  category=new FormControl('');

  SubmitButton:any="Submit";

  showsuccess:any=0;
  status:any;

  constructor(private router: Router, private http:HttpClient,private localstorage:LocalStorageService) {
    this.addPostForm = new FormGroup({
      title: this.title,
      body: this.body,
      imageurl: this.imageurl,
      time:this.time,
      category:this.category,
    });
  }

  ngOnInit(): void {
    // this.toastr.success('Hello world!', 'Toastr fun!');
  }

  assignprivatestatus()
  {
    this.status="private";
  }

  assignpublicstatus()
  {
    this.status="public";
  }

  addPost()
  {
    console.log("submit")
    event?.preventDefault();
    console.log(this.addPostForm.value,this.status);
    let postobj={
      "title":this.addPostForm.value.title,
      "content":this.addPostForm.value.body,
      "username":this.localstorage.retrieve("username"),
      "time":this.addPostForm.value.time+" Min Read",
      "date":String(new Date()).slice(4,15),
      "imgurl":this.addPostForm.value.imageurl,
      "category":this.addPostForm.value.category,
      "status":this.status,
      "likes":0
    }

    console.log(postobj);

    this.http.post("http://localhost:4501/api/posts",postobj).subscribe((res)=>{

    console.log("updated poset = ",res)

    this.showsuccess=1;


    })
  }

}
