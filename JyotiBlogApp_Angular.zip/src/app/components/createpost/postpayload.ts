export class postpayload{
    title:any;
    body :any;
    imageurl:any;
    time:any;
    category:any;
    username:any;
}