import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editpost',
  templateUrl: './editpost.component.html',
  styleUrls: ['./editpost.component.css']
})
export class EditpostComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
