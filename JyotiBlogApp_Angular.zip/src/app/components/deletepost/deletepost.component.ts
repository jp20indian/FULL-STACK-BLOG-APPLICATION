import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-deletepost',
  templateUrl: './deletepost.component.html',
  styleUrls: ['./deletepost.component.css']
})
export class DeletepostComponent implements OnInit {

  @Output() event1 = new EventEmitter<any>();

  constructor() { }

  ngOnInit(): void {
  }

  Cancelclicked(v:any)
  {
    this.event1.emit(v);
  }

  Deleteclicked(v:any)
  {
    this.event1.emit(v);
  }

}
