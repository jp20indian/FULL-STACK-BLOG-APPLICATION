import { Component, OnInit,Input } from '@angular/core';
import { Router } from '@angular/router';
declare function call():any;
import { Output, EventEmitter } from '@angular/core';
import { AuthserviceService } from 'src/app/services/authservice.service';
import { ThemechangeService } from 'src/app/services/themechange.service';
import { LocalStorageService } from 'ngx-webstorage';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  userloggedin:any=1;

  // @Input() item:any;
  @Output() newItemEvent = new EventEmitter<string>();
  @Output() newItemEvent1 = new EventEmitter<string>();

  
  sunclicked:any=1;
  moonclicked:any=0;
  current: string='';

  username:any;
  

  constructor(router: Router, private authservice:AuthserviceService,private themechangeservice:ThemechangeService,private localstorage:LocalStorageService) { 

    let currentPageUrl = router.url; // router.url contain the active route info
    currentPageUrl=currentPageUrl.slice(1,currentPageUrl.length);
    console.log('Activated router is ' + currentPageUrl);
    this.current=currentPageUrl;

    console.log(document.getElementById("#home"));

    this.username=localstorage.retrieve("username");


  }

  ngOnInit(): void {
    // call();
  }

  Login(value:any)
  {
    console.log("login");
    this.newItemEvent.emit(value);
    // this.item=1;
  }

  signup(value:any)
  {
    console.log("signup");
    this.newItemEvent1.emit(value);
  }

  themeclick(value:any)
  {
    if(value===1)
    {
      this.sunclicked=value;
      this.themechangeservice.sunclicked(1);
      console.log("sun click");
      this.moonclicked=0;
    }
    else
    {
      this.sunclicked=value;
      this.themechangeservice.moonclicked(1);
      console.log("moon click");
      this.moonclicked=1;
    }

  }

  highlighthome():String
  {
    if(this.current=="")
    {
      return"list-link current";
    }
    else return "list-link";
  }

  
  highlighttopposts():String
  {
    if(this.current=="topposts")
    {
      return"list-link current";
    }
    else return "list-link";
  }

  highlightallposts():String
  {
    if(this.current=="allposts")
    {
      return"list-link current";
    }
    else return "list-link";
  }

  highlightsubscription():any
  {
    if(this.current=="subscription")
    {
      return"list-link current";
    }
    else return "list-link";
  }

}
