import { Component, OnInit } from '@angular/core';
import { Output, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { LocalStorageService } from 'ngx-webstorage';
import { AuthserviceService } from 'src/app/services/authservice.service';

@Component({
  selector: 'app-comments',
  templateUrl: './comments.component.html',
  styleUrls: ['./comments.component.css']
})
export class CommentsComponent implements OnInit {

  @Output() newItemEvent = new EventEmitter<string>();

  comments:any;
  commentadded:any;
  post_id:any;
  likes:any;
  likeclicked:any=0;


  showcomment=0;

  constructor(private http:HttpClient,private route:ActivatedRoute,private localstorage:LocalStorageService,public authservice:AuthserviceService) { }

  ngOnInit(): void {

    this.getcommentsdata();

  }

  getcommentsdata()
  {
    this.post_id=this.route.snapshot.queryParams['postid']
    console.log(" post id in comments : ",this.post_id);

    this.http.get("http://localhost:4501/api/posts/"+this.post_id+"/comments").subscribe((res)=>{
      console.log("COMMENRS GET FROM SERVER",res);
      this.comments=res;
      this.comments.reverse();
    })
  }

  Close(value:any)
  {
    console.log("Inside Comments Section",value);
    this.newItemEvent.emit(value);
  }

  AddComment(e:any)
  {
    this.commentadded=e.path[0].innerHTML;
  }

  GetComment()
  {
    console.log("Comment = ",this.commentadded);

    let commentobj={
      "body":this.commentadded,
      "likes":0,
      "username":this.localstorage.retrieve("username"),
    }

    console.log(commentobj);

    this.http.post("http://localhost:4501/api/posts/"+this.post_id+"/comments",commentobj).subscribe((res)=>{
      console.log(" Comment added in database  ? ",res);

      this.http.get("http://localhost:4501/api/posts/"+this.post_id+"/comments").subscribe((res)=>{
        console.log("COMMENRS GET FROM SERVER",res);
        this.comments=res;
        this.comments.reverse();
      })


    })
  }

  IncreaseLike(comment:any)
  {
    if(this.authservice.Isauthenticated()&&this.likeclicked==0){
    console.log("Likes = ",comment,this.likeclicked);
    // this.likeclicked=1;
    this.http.get("http://localhost:4501/api/posts/"+this.post_id+"/comments/"+comment.id).subscribe((res)=>{
      console.log("Updated Comment : ",res);

      this.getcommentsdata();
    })
  }
   

  }

}
