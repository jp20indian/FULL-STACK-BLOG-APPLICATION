import { Component, Input, OnInit } from '@angular/core';
import { AuthserviceService } from 'src/app/services/authservice.service';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-topposts',
  templateUrl: './topposts.component.html',
  styleUrls: ['./topposts.component.css']
})
export class ToppostsComponent implements OnInit {


  // arr:any=[1,2,3,4,5,6,7,8,9,10,1,2,3,4,5,6,7,8,9,10,1,2,3,4,5,6,7,8,9,10,1,2,3,4,5,6,7,8,9,10]
    arr:any=[];
  constructor(public authservice:AuthserviceService,private http:HttpClient) { }

  ngOnInit(): void {

    this.http.get("http://localhost:4501/api/posts").subscribe((res:any)=>{

    for(let i=0;i<12;i++)
    {
      if(res[i].status=="public"){
      this.arr.push(res[i]);
      }
    }

    })

  }

}
