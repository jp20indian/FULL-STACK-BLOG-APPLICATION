import { Component, OnInit } from '@angular/core';
import { AuthserviceService } from 'src/app/services/authservice.service';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-allposts',
  templateUrl: './allposts.component.html',
  styleUrls: ['./allposts.component.css']
})
export class AllpostsComponent implements OnInit {

  // arr:any=[1,2,3,4,5,6,7,8,9,10,1,2,3,4,5,6,7,8,9,10,1,2,3,4,5,6,7,8,9,10,1,2,3,4,5,6,7,8,9,10]
 arr:any=[];
 category:any;
 username:any;
  constructor(public authservice:AuthserviceService,private http:HttpClient,private route:ActivatedRoute) { }

  ngOnInit(): void {

    this.category=this.route.snapshot.queryParams['category']
    this.username=this.route.snapshot.queryParams['username']
    if(this.category==null&&this.username==null){
    this.http.get("http://localhost:4501/api/posts").subscribe((res:any)=>{

    console.log("showing all posts")
      for(let i=0;i<res.length;i++)
      {
        if(res[i].status=="public"){
          console.log("sddddddd",res[i])
        this.arr.push(res[i]);
        }
      }
  
      })
    }
    else{

      if(this.category!=null){
      this.http.get("http://localhost:4501/api/posts").subscribe((res:any)=>{

        console.log("showing categorical posts")
      for(let i=0;i<res.length;i++)
      {
        if(res[i].category==this.category&&res[i].status=="public"){
        this.arr.push(res[i]);
        }
      }
  
      })
    }
    else if(this.username!=null)
    {
      console.log("showing username posts")
      this.http.get("http://localhost:4501/api/posts").subscribe((res:any)=>{

        for(let i=0;i<res.length;i++)
        {
          if(res[i].username==this.username&&res[i].status=="public"){
          this.arr.push(res[i]);
          }
        }
    
        })
    }
    }
  }

}
