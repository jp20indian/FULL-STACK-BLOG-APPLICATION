import { Component, OnInit } from '@angular/core';
import { AuthserviceService } from 'src/app/services/authservice.service';
@Component({
  selector: 'app-subscription',
  templateUrl: './subscription.component.html',
  styleUrls: ['./subscription.component.css']
})
export class SubscriptionComponent implements OnInit {

  loginitem='';
  signupitem:any;

  constructor(public authservice:AuthserviceService) { }

  ngOnInit(): void {
  }

  
  loggedin(e:any)
  {
    console.log("logged in",e)
    this.loginitem=e;
  }
  backlogin(e:any)
{
  this.loginitem=e;
}
submitlogin(e:any)
{
  console.log(e)
}

  signedup(e:any)
  {
    this.signupitem=e;
    console.log("nes signup item :",this.signupitem);
  }
  closesignup(e:any)
  {
    console.log(e," signup closed")
    this.signupitem=e;
  }

}
