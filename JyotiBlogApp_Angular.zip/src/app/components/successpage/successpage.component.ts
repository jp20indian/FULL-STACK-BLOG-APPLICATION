import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-successpage',
  templateUrl: './successpage.component.html',
  styleUrls: ['./successpage.component.css']
})
export class SuccesspageComponent implements OnInit {

  constructor(private route:Router) {  }

  ngOnInit(): void {
  }

  GoBackHome()
  {
    this.route.navigate([""]);
  }

}
