import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ToppostscontentComponent } from './toppostscontent.component';

describe('ToppostscontentComponent', () => {
  let component: ToppostscontentComponent;
  let fixture: ComponentFixture<ToppostscontentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ToppostscontentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ToppostscontentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
