import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-toppostscontent',
  templateUrl: './toppostscontent.component.html',
  styleUrls: ['./toppostscontent.component.css']
})
export class ToppostscontentComponent implements OnInit {

  @Input() item='any';

  constructor() { }

  ngOnInit(): void {
  }

}
