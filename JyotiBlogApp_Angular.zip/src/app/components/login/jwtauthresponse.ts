export class jwtauthresponse{
    authenticationtoken:String="";
    username:String=""
}