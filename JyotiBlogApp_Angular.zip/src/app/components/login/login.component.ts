import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Output, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { jwtauthresponse } from './jwtauthresponse';
import { catchError, map, Observable, of } from 'rxjs';
import { LocalStorageService } from 'ngx-webstorage';
import { AuthserviceService } from 'src/app/services/authservice.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  encapsulation: ViewEncapsulation.ShadowDom
})
export class LoginComponent implements OnInit {

  signupForm!: FormGroup;
  username: any = '';
  password: any = '';

  flag:any=0;
  logintext:any="Login"

  @Output() newItemEvent = new EventEmitter<string>();
  @Output() newItemEvent1 = new EventEmitter<string>();
  errorMessage: any;

  constructor(private fb: FormBuilder,private authservice:AuthserviceService) { }

  ngOnInit(): void {
    this.signupForm = this.fb.group({
      username: this.fb.control('', [Validators.required]),
      password: this.fb.control('', [Validators.required]),
    });
  }

  Back(e:any)
  {
    this.newItemEvent.emit(e);
  }

 Login(e:any)
 {
  e="login clicked";
  this.newItemEvent1.emit(e);
  console.log(this.signupForm.value.username);
 let obj={
    username:this.signupForm.value.username,
    password:this.signupForm.value.password
  }

  this.authservice.Login(obj)
  .pipe(catchError((error: any, caught: Observable<any>): Observable<any> => {
    this.errorMessage = error.message;
    console.error('There was an error!', error);
    this.logintext="Login Failed !"
    return of();
})).subscribe(data=>{
    if(data)
    {
      console.log("login Succes");
      this.logintext="Success!              Go back and Enjoy"
      this.flag=1;
    }
    else
    {
      console.log("login fail");
      this.logintext="Login Failed !"
    }
  })

 }


}
