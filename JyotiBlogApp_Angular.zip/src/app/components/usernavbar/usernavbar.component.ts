import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
declare function call():any;
import { Output, EventEmitter } from '@angular/core';
import { AuthserviceService } from 'src/app/services/authservice.service';
import { ThemechangeService } from 'src/app/services/themechange.service';
import { LocalStorageService } from 'ngx-webstorage';

@Component({
  selector: 'app-usernavbar',
  templateUrl: './usernavbar.component.html',
  styleUrls: ['./usernavbar.component.css']
})
export class UsernavbarComponent implements OnInit {

  @Output() newItemEvent = new EventEmitter<string>();
  @Output() newItemEvent1 = new EventEmitter<string>();

  sunclicked:any=0;
  moonclicked:any=1;

  username:any;

  current:any="";

  constructor(router: Router, private authservice:AuthserviceService,private themechangeservice:ThemechangeService,private localstorage:LocalStorageService) {
    let currentPageUrl = router.url; // router.url contain the active route info
    currentPageUrl=currentPageUrl.slice(1,currentPageUrl.length);
    console.log('Activated router is ' + currentPageUrl);
    this.current=currentPageUrl;

    console.log(document.getElementById("#home"));

    this.username=localstorage.retrieve("username");

   }

  ngOnInit(): void {
    
  }

  // Login(value:any)
  // {
  //   console.log("login");
  //   this.newItemEvent.emit(value);
  //   // this.item=1;
  // }
  Logout()
  {
    this.localstorage.clear("authenticationtoken");
    this.localstorage.clear("username");
  }

  // signup(value:any)
  // {
  //   console.log("signup");
  //   this.newItemEvent1.emit(value);
  // }

  themeclick(value:any)
  {
    if(value===1)
    {
      this.sunclicked=value;
      this.themechangeservice.sunclicked(1);
      console.log("sun click");
      this.moonclicked=0;
    }
    else
    {
      this.sunclicked=value;
      this.themechangeservice.moonclicked(1);
      console.log("moon click");
      this.moonclicked=1;
    }

  }

  highlighthome():String
  {
    if(this.current=="")
    {
      return"list-link current";
    }
    else return "list-link";
  }

  highlighttopposts():String
  {
    if(this.current=="topposts")
    {
      return"list-link current";
    }
    else return "list-link";
  }

  highlightallposts():String
  {
    if(this.current=="allposts")
    {
      return"list-link current";
    }
    else return "list-link";
  }

  highlightyourposts():String
  {
    if(this.current=="yourposts")
    {
      return"list-link current";
    }
    else return "list-link";
  }

  highlightcreate():String
  {
    if(this.current=="create")
    {
      return"list-link current";
    }
    else return "list-link";
  }

  highlightprivateposts():String
  {
    if(this.current=="private")
    {
      return"list-link current";
    }
    else return "list-link";
  }

  highlightpublicposts():String
  {
    if(this.current=="public")
    {
      return"list-link current";
    }
    else return "list-link";
  }

  highlightsubscription():any
  {
    if(this.current=="subscription")
    {
      return"list-link current";
    }
    else return "list-link";
  }


}
