import { Component, OnInit } from '@angular/core';
import { AuthserviceService } from 'src/app/services/authservice.service';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { LocalStorageService } from 'ngx-webstorage';
import { Router } from '@angular/router';

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements OnInit {

  CommentButton:any="Comments";

  loginitem='';
  signupitem='';
  postid:any;
  post:any;
  editpost:any=0;

  showcomments=0;

  likeflag:any=0;

  likecount:any;

  newtitle:any;
  newdate:any;
  newtime:any;
  newimgurl:any;
  newcontent:any;
  newcategory:any;
  newstatus:any;
  newusername:any;

  username:any;

  deletepostclicked:any=0;

  constructor(public authservice:AuthserviceService,private route:ActivatedRoute,private http:HttpClient,private localstorage:LocalStorageService,private router:Router) { }

  ngOnInit(): void {
    this.postid=this.route.snapshot.queryParams['postid']
    console.log("************ post id :",this.postid);

    this.username=this.localstorage.retrieve("username");

    this.http.get("http://localhost:4501/api/posts/"+this.postid).subscribe((res)=>{
      this.post=res;
      console.log("************ post:",this.post);

      this.newtitle=this.post.title;
      this.newdate=this.post.date;
      this.newtime=this.post.time;
      this.newimgurl=this.post.imgurl;
      this.newcontent=this.post.content;
      this.newcategory=this.post.category;
      this.newstatus=this.post.status;
      this.newusername=this.post.username;

      this.likecount=this.post.likes;


    });


    
  }

  loggedin(e:any)
  {
    this.loginitem=e;
  }
  backlogin(e:any)
{
  this.loginitem=e;
}
submitlogin(e:any)
{
  console.log(e)
}

  signedup(e:any)
  {
    this.signupitem=e;
  }
  closesignup(e:any)
  {
    this.signupitem=e;
  }

  ShowComments()
  {
    this.showcomments=1;
    console.log("showing comments ",this.showcomments);
  }

  CloseComments()
  {
    this.showcomments=0;
    console.log("closing comments",this.showcomments)
  }

  EditClicked()
  {
    console.log("Edit Clicked");
    // this.editpost=1;
    if(this.post.username==this.localstorage.retrieve("username"))
      {
        this.editpost=1;
      }
  }

  assigntitle(e:any)
  {
    console.log(e.path[0].innerHTML);
    this.newtitle=e.path[0].innerHTML;
  }

  assigndate(e:any)
  {
    console.log(e.path[0].innerHTML);
    this.newdate=e.path[0].innerHTML;
  }

  assigntime(e:any)
  {
    console.log(e.path[0].innerHTML);
    this.newtime=e.path[0].innerHTML;
  }

  assignimgurl(e:any)
  {
    console.log(e.path[0].innerHTML);
    this.newimgurl=e.path[0].innerHTML;
  }

  assigncontent(e:any)
  {
    console.log(e.path[0].innerHTML);
    this.newcontent=e.path[0].innerHTML;
  }

  assigncategory(e:any)
  {
    console.log(e.path[0].innerHTML);
    this.newcategory=e.path[0].innerHTML;
  }

  assignstatus(e:any)
  {
    this.newstatus=e.path[0].innerHTML;
  }

  SaveEditedPost(e:any)
  {
    console.log("Save Edited post",this.newtitle,this.newdate,this.newdate,this.newimgurl,this.newcontent,this.postid,this.newcategory);

    let postobj={
      "title":this.newtitle,
      "content":this.newcontent,
      "username":this.username,
      "time":this.newtime,
      "date":this.newdate,
      "imgurl":this.newimgurl,
      "category":this.newcategory,
      "status":this.newstatus
    }

    this.http.post("http://localhost:4501/api/posts/"+this.postid,postobj).subscribe((res)=>{

    alert("Edited Post Successfully Saved !")
    })

  }

  LikeClicked()
  {
    if(this.likeflag==0)
    {
      console.log("increase like");

      let postobj={
        "title":this.newtitle,
        "content":this.newcontent,
        "username":this.newusername,
        "time":this.newtime,
        "date":this.newdate,
        "imgurl":this.newimgurl,
        "category":this.newcategory,
        "status":this.newstatus,
        "likes": (parseInt(this.likecount)+1).toString()
      }

      this.http.post("http://localhost:4501/api/posts/"+this.postid+"/updatelike",postobj).subscribe((res)=>{

        this.http.get("http://localhost:4501/api/posts/"+this.postid).subscribe((res)=>{
          this.post=res;
  
          this.likecount=this.post.likes;
          this.likeflag=1;
    
    
        });

      })
    }
    else
    {
      console.log("decrease like");
      let postobj={
        "title":this.newtitle,
        "content":this.newcontent,
        "username":this.newusername,
        "time":this.newtime,
        "date":this.newdate,
        "imgurl":this.newimgurl,
        "category":this.newcategory,
        "status":this.newstatus,
        "likes": (parseInt(this.likecount)-1).toString()
      }

      this.http.post("http://localhost:4501/api/posts/"+this.postid+"/updatelike",postobj).subscribe((res)=>{

        this.http.get("http://localhost:4501/api/posts/"+this.postid).subscribe((res)=>{
          this.post=res;
  
          this.likecount=this.post.likes;
          this.likeflag=0;
    
    
        });

      })
    }
  }

  DeleteClicked()
  {
    console.log("Delete clicked");
    this.deletepostclicked=1;
  }

  delete(e:any)
  {
    if(e==0){
    console.log("DONT DELETE");
    this.deletepostclicked=0;
    }
    else
    {
      console.log(" DELETE POSt");
      this.deletepostclicked=0;
      this.http.get("http://localhost:4501/api/posts/"+this.postid+"/delete").subscribe((res)=>{
        console.log("POST SUCCESSFULLY DELETED!")
        
      })
    }
    this.router.navigate([""]).then(()=>{
      window.location.reload();
    })

  }

  ShowsAllPostsByUsername()
  {
    console.log("ShowsAllPostsByUsername()");
    this.router.navigate(['/allposts'],{queryParams:{username:this.newusername}});
  }

}
