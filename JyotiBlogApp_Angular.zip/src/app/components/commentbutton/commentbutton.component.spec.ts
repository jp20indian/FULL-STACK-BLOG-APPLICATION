import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CommentbuttonComponent } from './commentbutton.component';

describe('CommentbuttonComponent', () => {
  let component: CommentbuttonComponent;
  let fixture: ComponentFixture<CommentbuttonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CommentbuttonComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CommentbuttonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
