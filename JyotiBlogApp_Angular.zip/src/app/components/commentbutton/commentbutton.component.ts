import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-commentbutton',
  templateUrl: './commentbutton.component.html',
  styleUrls: ['./commentbutton.component.css']
})
export class CommentbuttonComponent implements OnInit {

  @Input() item: any;

  constructor() { }

  ngOnInit(): void {
  }

}
