import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginbuttonsComponent } from './loginbuttons.component';

describe('LoginbuttonsComponent', () => {
  let component: LoginbuttonsComponent;
  let fixture: ComponentFixture<LoginbuttonsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoginbuttonsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LoginbuttonsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
