import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loginbuttons',
  templateUrl: './loginbuttons.component.html',
  styleUrls: ['./loginbuttons.component.css']
})
export class LoginbuttonsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
