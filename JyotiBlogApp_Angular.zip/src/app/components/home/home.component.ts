import { Component, OnInit,Input } from '@angular/core';
import { AuthserviceService } from 'src/app/services/authservice.service';
import { HttpClient } from '@angular/common/http';
import { FeatureddataService } from 'src/app/services/featureddata.service';
import { Router } from '@angular/router';
declare function call():any;

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  loginitem='';
  signupitem:any;
  allposts:any;
  featuredposts:any=[];
  trendingposts:any=[];
  oldposts:any=[];
  constructor(public authservice:AuthserviceService,private http:HttpClient,private featureddataservice:FeatureddataService,private router: Router) {

    
  
   }

  ngOnInit(): void {
    console.log("login Status : ",this.authservice.Isauthenticated());


  }

  emitposts(featuredposts:any,trendingposts:any,oldposts:any)
  {
    console.log(featuredposts,trendingposts,oldposts);
  }

  loggedin(e:any)
  {
    console.log("logged in",e)
    this.loginitem=e;
  }
  backlogin(e:any)
{
  this.loginitem=e;
}
submitlogin(e:any)
{
  console.log(e)
}

  signedup(e:any)
  {
    this.signupitem=e;
    console.log("nes signup item :",this.signupitem);
  }
  closesignup(e:any)
  {
    console.log(e," signup closed")
    this.signupitem=e;
  }

  OpenTravelPosts()
  {
    this.router.navigate(['/allposts'],{queryParams:{category:"travel"}});
  }

  OpenFoodPosts()
  {
    this.router.navigate(['/allposts'],{queryParams:{category:"food"}});
  }

  OpenTechnologyPosts()
  {
    this.router.navigate(['/allposts'],{queryParams:{category:"technology"}});
  }

  OpenHealthPosts()
  {
    this.router.navigate(['/allposts'],{queryParams:{category:"health"}});
  }

  OpenNaturePosts()
  {
    this.router.navigate(['/allposts'],{queryParams:{category:"nature"}});
  }

  OpenFitnessPosts()
  {
    this.router.navigate(['/allposts'],{queryParams:{category:"fitness"}});
  }


}


