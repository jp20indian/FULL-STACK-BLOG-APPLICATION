import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-writtenby',
  templateUrl: './writtenby.component.html',
  styleUrls: ['./writtenby.component.css']
})
export class WrittenbyComponent implements OnInit {

  @Input() item: any;

  constructor() { }

  ngOnInit(): void {
  }

}
