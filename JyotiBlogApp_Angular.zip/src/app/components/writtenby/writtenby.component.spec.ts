import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WrittenbyComponent } from './writtenby.component';

describe('WrittenbyComponent', () => {
  let component: WrittenbyComponent;
  let fixture: ComponentFixture<WrittenbyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WrittenbyComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WrittenbyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
