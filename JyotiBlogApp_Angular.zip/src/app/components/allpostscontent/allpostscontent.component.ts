import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-allpostscontent',
  templateUrl: './allpostscontent.component.html',
  styleUrls: ['./allpostscontent.component.css']
})
export class AllpostscontentComponent implements OnInit {

  @Input() item = [];
  @Input() item2 = '';
  @Input() item3 = '';
  items:any;

  constructor(private router:Router,private http:HttpClient) { 



  }

  ngOnInit(): void {

    this.items=this.item;
    console.log("In all posts content",this.item);
    
  }

  OpenPost(i:any)
  {
    console.log(i);
    this.router.navigate(['/post'],{queryParams:{postid:i.id}});
  }

}
