import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllpostscontentComponent } from './allpostscontent.component';

describe('AllpostscontentComponent', () => {
  let component: AllpostscontentComponent;
  let fixture: ComponentFixture<AllpostscontentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AllpostscontentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AllpostscontentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
