import { Component, OnInit } from '@angular/core';
import { AuthserviceService } from 'src/app/services/authservice.service';
import { HttpClient } from '@angular/common/http';
import { LocalStorageService } from 'ngx-webstorage';

@Component({
  selector: 'app-privateposts',
  templateUrl: './privateposts.component.html',
  styleUrls: ['./privateposts.component.css']
})
export class PrivatepostsComponent implements OnInit {

  arr:any=[];

  constructor(public authservice:AuthserviceService,private http:HttpClient,private localstorage:LocalStorageService) { }

  ngOnInit(): void {

    this.http.get("http://localhost:4501/api/posts").subscribe((res:any)=>{

      for(let i=0;i<res.length;i++)
      {
        console.log("SHowing private posts with ",this.localstorage.retrieve("username"))
        if(res[i].status==="private"&&this.localstorage.retrieve("username")==res[i].username){
        this.arr.push(res[i]);
        console.log(res[i]);
        }
      }
  })

}
}
