import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrivatepostsComponent } from './privateposts.component';

describe('PrivatepostsComponent', () => {
  let component: PrivatepostsComponent;
  let fixture: ComponentFixture<PrivatepostsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PrivatepostsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PrivatepostsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
