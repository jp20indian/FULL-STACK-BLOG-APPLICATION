import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { FeaturedComponent } from './homecomponents/featured/featured.component';
import { FeaturedcontentComponent } from './homecomponents/featuredcontent/featuredcontent.component';
import { TrendingComponent } from './homecomponents/trending/trending.component';
import { OldpostsComponent } from './homecomponents/oldposts/oldposts.component';
import { OldpostComponent } from './homecomponents/oldpost/oldpost.component';
import { FooterComponent } from './components/footer/footer.component';
import { NewsletterComponent } from './components/newsletter/newsletter.component';
import { PostComponent } from './components/post/post.component';
import { TrendingpostComponent } from './homecomponents/trendingpost/trendingpost.component';
import { SignupComponent } from './components/signup/signup.component';
import { LoginComponent } from './components/login/login.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
// import { SwiperModule } from 'swiper/angular';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

import { NgxWebstorageModule } from 'ngx-webstorage';
import { CreatepostComponent } from './components/createpost/createpost.component';
import { UsernavbarComponent } from './components/usernavbar/usernavbar.component';
import { EditorModule } from '@tinymce/tinymce-angular';
import { HttpClientInterceptor } from './http-client-interceptor';
import { ButtonComponent } from './components/button/button.component';
import { CommentsComponent } from './components/comments/comments.component';
import { CommentbuttonComponent } from './components/commentbutton/commentbutton.component';
import { SignupbuttonsComponent } from './components/signupbuttons/signupbuttons.component';
import { LoginbuttonsComponent } from './components/loginbuttons/loginbuttons.component';
import { EditpostComponent } from './components/editpost/editpost.component';
import { AllpostsComponent } from './components/allposts/allposts.component';
import { AllpostscontentComponent } from './components/allpostscontent/allpostscontent.component';
import { ToppostsComponent } from './components/topposts/topposts.component';
import { ToppostcontentComponent } from './components/toppostcontent/toppostcontent.component';
import { ToppostscontentComponent } from './components/toppostscontent/toppostscontent.component';
// import { ToastrModule, ToastNoAnimation, ToastNoAnimationModule } from 'ngx-toastr';
import { SuccesspageComponent } from './components/successpage/successpage.component';
import { PrivatepostsComponent } from './components/privateposts/privateposts.component';
import { PublicpostsComponent } from './components/publicposts/publicposts.component';
import { DeletepostComponent } from './components/deletepost/deletepost.component';
import { SubscriptionComponent } from './components/subscription/subscription.component';
import { WrittenbyComponent } from './components/writtenby/writtenby.component';

// import {
//   MatButtonModule
// } from '@angular/material/button';
// import {
//   MatDialogModule
// } from '@angular/material/dialog';
// import {
//   MatFormFieldModule
// } from '@angular/material/form-field';
// import {
//   MatInputModule
// } from '@angular/material/input';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    NavbarComponent,
    FeaturedComponent,
    FeaturedcontentComponent,
    TrendingComponent,
    OldpostsComponent,
    OldpostComponent,
    FooterComponent,
    NewsletterComponent,
    PostComponent,
    TrendingpostComponent,
    SignupComponent,
    LoginComponent,
    CreatepostComponent,
    UsernavbarComponent,
    ButtonComponent,
    CommentsComponent,
    CommentbuttonComponent,
    SignupbuttonsComponent,
    LoginbuttonsComponent,
    EditpostComponent,
    AllpostsComponent,
    AllpostscontentComponent,
    ToppostsComponent,
    ToppostcontentComponent,
    ToppostscontentComponent,
    SuccesspageComponent,
    PrivatepostsComponent,
    PublicpostsComponent,
    DeletepostComponent,
    SubscriptionComponent,
    WrittenbyComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    EditorModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgxWebstorageModule.forRoot(),
    // ToastNoAnimationModule.forRoot()
  ],
  providers: [{provide: HTTP_INTERCEPTORS, useClass: HttpClientInterceptor, multi: true}],
  bootstrap: [AppComponent]
})
export class AppModule { }
