import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { jwtauthresponse } from '../components/login/jwtauthresponse';
import { LocalStorageService } from 'ngx-webstorage';
import { map, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthserviceService {

  constructor(private http:HttpClient,private localstorage:LocalStorageService) { }

  Login(logindata:any): Observable<boolean>
  {

    // console.log("auth servive1")

    return this.http.post("http://localhost:4501/api/auth/login", logindata,{responseType: 'text'}).pipe(map (  data => {

    console.log(data);
    console.log(logindata.username);
      this.localstorage.store('authenticationtoken', data);
      this.localstorage.store('username', logindata.username);
      return true;
    }));

  }

  Isauthenticated()
  {
    return this.localstorage.retrieve('username')!==null;
  }
}
