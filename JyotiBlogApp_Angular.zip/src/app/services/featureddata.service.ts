import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FeatureddataService {

  allposts:any=[];
  allvalid:any=[];
  featuredposts:any=[];
  trendingposts:any=[];
  oldposts:any=[];

  constructor(private http:HttpClient) { 
    // this.http.get("http://localhost:4501/api/posts/1/comments").subscribe(res=>{
      this.http.get("http://localhost:4501/api/posts").subscribe(res=>{
      console.log("4444444444444444444444444444444444444444",res);

      this.allposts=res;
      for(let i1=0;i1<this.allposts.length;i1++)
      {
        if(this.allposts[i1].status=="public")
        {
          console.log("valid------",this.allposts[i1]);
        this.allvalid.push(this.allposts[i1]);
        }
      }

      let i=0;

      while(i<=2)
      {
        this.featuredposts.push(this.allvalid[i]);
        i++;
      }

      while(i<=6)
      {
        this.trendingposts.push(this.allvalid[i]);
        i++;
      }

      
      while(i<=12)
      {
        this.oldposts.push(this.allvalid[i]);
        i++;
      }

    })
  }


}
