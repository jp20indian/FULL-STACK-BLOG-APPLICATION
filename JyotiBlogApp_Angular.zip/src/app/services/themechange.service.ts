import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ThemechangeService {

  constructor() { }

  sunclicked(value: any) {
    const body = document.body;
    body.className = "light-theme";
  }

  moonclicked(value: any) {
    const body = document.body;
    body.className = "";
  }
}
