import { TestBed } from '@angular/core/testing';

import { FeatureddataService } from './featureddata.service';

describe('FeatureddataService', () => {
  let service: FeatureddataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FeatureddataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
