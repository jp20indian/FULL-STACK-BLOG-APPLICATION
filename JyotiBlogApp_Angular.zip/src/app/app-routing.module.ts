import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PostComponent } from './components/post/post.component';
import { HomeComponent } from './components/home/home.component';
import { SignupComponent } from './components/signup/signup.component';
import { LoginComponent } from './components/login/login.component';
import { CreatepostComponent } from './components/createpost/createpost.component';
import { CommentsComponent } from './components/comments/comments.component';
import { SignupbuttonsComponent } from './components/signupbuttons/signupbuttons.component';
import { ButtonComponent } from './components/button/button.component';
import { AllpostsComponent } from './components/allposts/allposts.component';
import { ToppostsComponent } from './components/topposts/topposts.component';
import { SuccesspageComponent } from './components/successpage/successpage.component';
import { PrivatepostsComponent } from './components/privateposts/privateposts.component';
import { PublicpostsComponent } from './components/publicposts/publicposts.component';
import { DeletepostComponent } from './components/deletepost/deletepost.component';
import { SubscriptionComponent } from './components/subscription/subscription.component';

const routes: Routes = [
  { path: 'post', component: PostComponent },
  { path: '', redirectTo: '', pathMatch: 'full', component:HomeComponent },
  {path:'signup', component:SignupComponent},
  {path:'login',component:LoginComponent},
  {path:'create',component:CreatepostComponent},
  {path:'comments',component:CommentsComponent},
  {path:'signupbuttons',component:SignupbuttonsComponent},
  {path:'button',component:ButtonComponent},
  {path:'allposts',component:AllpostsComponent},
  {path:'topposts',component:ToppostsComponent},
  {path:'success',component:SuccesspageComponent},
  {path:'private',component:PrivatepostsComponent},
  {path:'public',component:PublicpostsComponent},
  {path:'deletepost',component:DeletepostComponent},
  {path:'subscription',component:SubscriptionComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
