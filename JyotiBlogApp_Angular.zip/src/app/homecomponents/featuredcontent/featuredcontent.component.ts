import { Component, Input, OnInit } from '@angular/core';
import { FeatureddataService } from 'src/app/services/featureddata.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-featuredcontent',
  templateUrl: './featuredcontent.component.html',
  styleUrls: ['./featuredcontent.component.css']
})
export class FeaturedcontentComponent implements OnInit {

  featureddata:any;
  news:any=[];
  headline:any='India Beats England ! To Face Arch Rival Pakistan in ICC T20 Finals';
  

  @Input() item:any;
  constructor(featureddataservice:FeatureddataService,private router: Router,private http:HttpClient) {

    setInterval(()=>{

      this.http.get("http://localhost:3000/news").subscribe((res)=>{
        console.log(res);
        this.news=res;
  
        const randomElement = this.news[Math.floor(Math.random() * this.news.length)];
        console.log(randomElement,Math.floor(Math.random() * this.news.length));
        
        this.headline=randomElement.headline;
  
      })

    },5000);

   }

  ngOnInit(): void {


  }

  OpenPost(id:any)
  {
    this.router.navigate(['/post'],{queryParams:{postid:id}});
  }

}
