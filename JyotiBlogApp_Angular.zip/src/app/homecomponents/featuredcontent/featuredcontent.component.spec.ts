import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FeaturedcontentComponent } from './featuredcontent.component';

describe('FeaturedcontentComponent', () => {
  let component: FeaturedcontentComponent;
  let fixture: ComponentFixture<FeaturedcontentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FeaturedcontentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FeaturedcontentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
