import { Component, OnInit } from '@angular/core';
import { FeatureddataService } from 'src/app/services/featureddata.service';

@Component({
  selector: 'app-oldposts',
  templateUrl: './oldposts.component.html',
  styleUrls: ['./oldposts.component.css']
})
export class OldpostsComponent implements OnInit {

  oldposts:any=[];

    constructor(featureddataservice:FeatureddataService) {
  
      this.oldposts=featureddataservice.oldposts;
      console.log("oldposts",this.oldposts)
    
     }
  


  ngOnInit(): void {
  }

  // imgurl:any="../../../assets/older_posts/older_posts_1.jpg";

}
