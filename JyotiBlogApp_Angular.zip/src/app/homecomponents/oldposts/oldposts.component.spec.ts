import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OldpostsComponent } from './oldposts.component';

describe('OldpostsComponent', () => {
  let component: OldpostsComponent;
  let fixture: ComponentFixture<OldpostsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OldpostsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OldpostsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
