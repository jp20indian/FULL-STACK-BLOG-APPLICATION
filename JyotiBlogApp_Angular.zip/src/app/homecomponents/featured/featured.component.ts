import { Component, Input, OnInit } from '@angular/core';
import { FeatureddataService } from 'src/app/services/featureddata.service';

@Component({
  selector: 'app-featured',
  templateUrl: './featured.component.html',
  styleUrls: ['./featured.component.css']
})
export class FeaturedComponent implements OnInit {

  featuredcontent:any;
  trendingcontent:any;

  constructor(private featureddataservice:FeatureddataService) { 
    // console.log("featured posts",this.item)
    this.featuredcontent=featureddataservice.featuredposts;
    this.trendingcontent=featureddataservice.trendingposts;
  }
  
  ngOnChange():void{
    // console.log("featured posts",this.item)
  }

  ngOnInit(): void {
  }

}
