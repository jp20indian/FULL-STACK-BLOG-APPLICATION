import { Component, Input, OnInit } from '@angular/core';
import { FeatureddataService } from 'src/app/services/featureddata.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-oldpost',
  templateUrl: './oldpost.component.html',
  styleUrls: ['./oldpost.component.css']
})
export class OldpostComponent implements OnInit {

  @Input() item:any;
  descr:any;
  
  constructor(private router: Router)
  {

  }

  ngOnInit(): void {
  }

  OpenPost(id:any)
  {
    this.router.navigate(['/post'],{queryParams:{postid:this.item.id}});
  }

}
