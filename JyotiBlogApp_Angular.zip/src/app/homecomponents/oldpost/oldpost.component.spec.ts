import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OldpostComponent } from './oldpost.component';

describe('OldpostComponent', () => {
  let component: OldpostComponent;
  let fixture: ComponentFixture<OldpostComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OldpostComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OldpostComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
