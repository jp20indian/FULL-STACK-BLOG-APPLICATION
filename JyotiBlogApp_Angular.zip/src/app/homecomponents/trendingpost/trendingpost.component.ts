import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trendingpost',
  templateUrl: './trendingpost.component.html',
  styleUrls: ['./trendingpost.component.css']
})
export class TrendingpostComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
