import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrendingpostComponent } from './trendingpost.component';

describe('TrendingpostComponent', () => {
  let component: TrendingpostComponent;
  let fixture: ComponentFixture<TrendingpostComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TrendingpostComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TrendingpostComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
