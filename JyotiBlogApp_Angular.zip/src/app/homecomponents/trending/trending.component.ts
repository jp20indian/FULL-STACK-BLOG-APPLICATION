import { Component, Input, OnInit } from '@angular/core';
import { FeatureddataService } from 'src/app/services/featureddata.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-trending',
  templateUrl: './trending.component.html',
  styleUrls: ['./trending.component.css']
})
export class TrendingComponent implements OnInit {

  @Input() item:any;

  constructor(private router: Router) {

    console.log("trending data -----------",this.item);

   }

  ngOnInit(): void {
  }

  OpenPost(id:any)
  {
    this.router.navigate(['/post'],{queryParams:{postid:id}});
  }

}
