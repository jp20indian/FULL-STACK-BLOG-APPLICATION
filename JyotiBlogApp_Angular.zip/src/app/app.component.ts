import { Component, OnInit, AfterViewInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

declare function call(): any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  currentItem:any;
  constructor(router:HttpClient){}

  ngOnInit(): void {
    // call();
    // throw new Error('Method not implemented.');
  }
  ngAfterViewInit() {
    console.log("after view init");
  }
  title = 'my-blog-app';

  addItem(e:any)
  {
    console.log("in app"+e);
    this.currentItem=e;
  }
}
